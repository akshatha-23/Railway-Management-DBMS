<?php
  session_start();
  // $con=mysqli_connect("sql202.epizy.com","epiz_30509297","9DFntaxoRvZpK","epiz_30509297_DBMS	");
  $con=mysqli_connect("localhost","root","","dbms");
?>